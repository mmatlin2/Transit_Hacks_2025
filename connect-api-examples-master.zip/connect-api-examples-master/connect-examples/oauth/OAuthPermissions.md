# Square Connect v2 API OAuth Scopes

The Square Connect v2 API requires OAuth scopes with every call to a Connect
endpoint.  [OAuth: Permissions Reference](https://developer.squareup.com/docs/oauth-api/square-permissions)
provided all needed permissions (scopes) for each endpoint in a Connect v2 service.
