## The _v1_ code samples are deprecated
The samples in this folder are no longer maintained.  For the most up-to-date samples, please refer to the following: 

* [`connect-examples/v2`](https://github.com/square/connect-api-examples/tree/master/connect-examples/v2) - samples demonstrating Square API functionality
* [`connect-examples/oauth`](https://github.com/square/connect-api-examples/tree/master/connect-examples/oauth) - samples demonstrating OAuth functionality
* [`templates`](https://github.com/square/connect-api-examples/tree/master/templates) - code blocks and function definitions to simplify common usage
