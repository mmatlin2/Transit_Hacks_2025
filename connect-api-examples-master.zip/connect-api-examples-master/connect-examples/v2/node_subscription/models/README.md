# Models

This directory contains classes that abstracts the data for the templates found in the [Views](../views/README.md) directory

## subscription-details-info.js

Defines a class that translate subscription plan details and current subscription status into a human readable model.
