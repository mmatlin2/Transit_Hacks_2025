# Public

We keep our publicly available files in this directory. This directory contains on sub-directory `stylesheets`.


## Stylesheets

This directory contains all of the client side css styling for this demo application. The rendered HTML loads these files as needed via the link tag.
